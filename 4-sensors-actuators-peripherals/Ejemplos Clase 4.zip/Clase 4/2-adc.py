from machine import Pin, ADC
from time import sleep_ms

adc = ADC(Pin(35), atten=ADC.ATTN_11DB)

while True:
    print(f"{adc.read_uv()} uV ({adc.read()})")
    sleep_ms(100)