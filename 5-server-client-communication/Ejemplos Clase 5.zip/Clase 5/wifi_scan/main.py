import network

wlan = network.WLAN(network.STA_IF)
if not wlan.active():
   wlan.active(True)

redes = wlan.scan()
for red in redes:
    print(f"{red[0]}. Canal {red[2]}. RSSI: {red[3]}")